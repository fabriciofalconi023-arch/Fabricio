package com.juriti.gamerturbo

import java.io.BufferedReader
import java.io.InputStreamReader

/** Runs explicitly requested shell commands in the Shizuku UserService process. */
class CommandService : ICommandService.Stub() {
    override fun runCommand(command: String): String {
        if (command.isBlank()) return "ERRO: comando vazio."
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val error = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            if (code == 0) output.ifBlank { "OK" } else "ERRO: ${error.ifBlank { output }}"
        } catch (e: Throwable) {
            "ERRO: ${e.message ?: "falha ao executar comando"}"
        }
    }

    @Suppress("unused")
    fun destroy() {
        kotlin.system.exitProcess(0)
    }
}
