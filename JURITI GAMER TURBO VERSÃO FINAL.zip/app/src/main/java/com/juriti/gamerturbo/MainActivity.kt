package com.juriti.gamerturbo

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.graphics.Color
import android.content.Intent
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.provider.Settings
import android.app.NotificationManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import android.net.TrafficStats
import android.content.IntentFilter

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private val requestCode = 7412
    private val addonZipRequestCode = 8765
    @Volatile private var previousCpuTotal = 0L
    @Volatile private var previousCpuIdle = 0L
    @Volatile private var previousRx = -1L
    @Volatile private var previousTx = -1L
    @Volatile private var previousMetricTime = 0L
    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        jsMessage(if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) "Autorização do Shizuku concedida ao JURITI." else "Autorização do Shizuku não concedida.")
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("checkShizuku()", null) }
    }

    private fun jsMessage(message: String) {
        val safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("toast('$safe')", null) }
    }

    private fun shizukuReady(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    private fun hasPermission(): Boolean = try {
        shizukuReady() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    private fun runShell(command: String): String {
        if (!hasPermission()) return "ERRO: Shizuku não está conectado ou a permissão não foi concedida."
        val latch = CountDownLatch(1)
        var remote: ICommandService? = null
        val args = Shizuku.UserServiceArgs(ComponentName(this, CommandService::class.java))
            .daemon(false)
            .tag("juriti-command-service")
            .version(1)
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                remote = ICommandService.Stub.asInterface(binder)
                latch.countDown()
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                remote = null
                latch.countDown()
            }
        }
        return try {
            Shizuku.bindUserService(args, connection)
            if (!latch.await(8, TimeUnit.SECONDS)) return "ERRO: tempo esgotado ao conectar ao serviço Shizuku."
            remote?.runCommand(command) ?: "ERRO: serviço Shizuku indisponível."
        } catch (e: Throwable) {
            "ERRO: ${e.message ?: "falha ao executar comando"}"
        } finally {
            try { Shizuku.unbindUserService(args, connection, true) } catch (_: Throwable) {}
        }
    }

    inner class AppBridge {
        @android.webkit.JavascriptInterface fun chooseAddonZip() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/zip"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                    }
                    startActivityForResult(intent, addonZipRequestCode)
                } catch (e: Throwable) { jsMessage("Não foi possível abrir o seletor de ZIP: ${e.message ?: "erro do Android"}") }
            }
        }

        @android.webkit.JavascriptInterface fun listJuritiAddons(): String = addonListJson().toString()

        @android.webkit.JavascriptInterface fun setJuritiAddonEnabled(id: String, enabled: Boolean): String {
            val safeId = id.trim()
            if (!safeId.matches(Regex("[a-zA-Z0-9._-]{1,64}"))) return "ERRO: identificador de add-on inválido."
            val dir = java.io.File(filesDir, "juriti-addons/$safeId")
            if (!java.io.File(dir, "manifest.json").isFile) return "ERRO: add-on não encontrado."
            getSharedPreferences("juriti_addons", MODE_PRIVATE).edit().putBoolean("enabled_$safeId", enabled).apply()
            return if (enabled) "Add-on ativado. Ele só executa ações declaradas e permitidas pelo JURITI." else "Add-on desativado."
        }

        @android.webkit.JavascriptInterface fun removeJuritiAddon(id: String): String {
            val safeId = id.trim()
            if (!safeId.matches(Regex("[a-zA-Z0-9._-]{1,64}"))) return "ERRO: identificador de add-on inválido."
            val dir = java.io.File(filesDir, "juriti-addons/$safeId")
            if (!dir.exists()) return "ERRO: add-on não encontrado."
            dir.deleteRecursively()
            getSharedPreferences("juriti_addons", MODE_PRIVATE).edit().remove("enabled_$safeId").apply()
            return "Add-on removido."
        }

        @android.webkit.JavascriptInterface fun pingLatency(): String {
            if (!hasPermission()) return "N/D"
            return try {
                val result = runShell("ping -c 1 -W 2 1.1.1.1 2>&1")
                val match = Regex("time[=<]([0-9.]+)").find(result)
                match?.groupValues?.get(1)?.toDoubleOrNull()?.toInt()?.toString() ?: "N/D"
            } catch (_: Throwable) { "N/D" }
        }

        @android.webkit.JavascriptInterface fun overlayStatus(): String = if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity)) "Permissão de sobreposição concedida." else "Permissão de sobreposição necessária."

        @android.webkit.JavascriptInterface fun isOverlayRunning(): Boolean {
            return OverlayService.isRunning
        }

        @android.webkit.JavascriptInterface fun startOverlay(): String {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread { try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
                return "Autorize 'Exibir sobre outros apps' para ativar o painel flutuante. Depois volte ao JURITI e toque novamente."
            }
            return try {
                val i = Intent(this@MainActivity, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                "Solicitação enviada para iniciar o painel. Se ele não aparecer, confira a permissão 'Exibir sobre outros apps' e as notificações do aplicativo."
            } catch (e: Throwable) { "ERRO: não foi possível iniciar o painel: ${e.message ?: "falha do Android"}" }
        }

        @android.webkit.JavascriptInterface fun stopOverlay(): String {
            stopService(Intent(this@MainActivity, OverlayService::class.java))
            return "Solicitação enviada para encerrar o painel flutuante."
        }

        @android.webkit.JavascriptInterface fun systemMetrics(): String {
            return try {
                val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
                val mi = android.app.ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
                var cpu: Int? = null
                try {
                    val fields = java.io.File("/proc/stat").readLines().first().trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
                    val idle = fields[3] + (fields.getOrNull(4) ?: 0L)
                    val total = fields.sum()
                    synchronized(this@MainActivity) {
                        if (previousCpuTotal > 0L && total > previousCpuTotal) {
                            val dt = total - previousCpuTotal; val di = idle - previousCpuIdle
                            cpu = (((dt - di).toDouble() / dt.toDouble()) * 100.0).toInt().coerceIn(0, 100)
                        }
                        previousCpuTotal = total; previousCpuIdle = idle
                    }
                } catch (_: Throwable) { }
                var batteryTemp: Double? = null
                try {
                    val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val raw = battery?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
                    if (raw > 0) batteryTemp = raw / 10.0
                } catch (_: Throwable) { }
                val now = android.os.SystemClock.elapsedRealtime()
                val rx = TrafficStats.getTotalRxBytes(); val tx = TrafficStats.getTotalTxBytes()
                var rxMbps: Double? = null; var txMbps: Double? = null
                synchronized(this@MainActivity) {
                    if (previousMetricTime > 0 && rx >= 0 && tx >= 0 && rx >= previousRx && tx >= previousTx) {
                        val seconds = ((now - previousMetricTime).coerceAtLeast(1L)) / 1000.0
                        rxMbps = ((rx - previousRx) * 8.0 / seconds / 1_000_000.0)
                        txMbps = ((tx - previousTx) * 8.0 / seconds / 1_000_000.0)
                    }
                    previousRx = rx; previousTx = tx; previousMetricTime = now
                }
                val out = JSONObject().put("totalRam", mi.totalMem).put("availableRam", mi.availMem)
                    .put("usedRam", mi.totalMem-mi.availMem).put("lowMemory",mi.lowMemory)
                if (cpu != null) out.put("cpuPercent", cpu)
                if (batteryTemp != null) out.put("batteryTempC", batteryTemp)
                if (rxMbps != null) out.put("rxMbps", rxMbps)
                if (txMbps != null) out.put("txMbps", txMbps)
                out.toString()
            } catch (_: Throwable) { "{}" }
        }

        @android.webkit.JavascriptInterface fun openPrivateDnsSettings(): String = openSystemScreen("android.settings.PRIVATE_DNS_SETTINGS", "Abrindo as opções de DNS privado do Android.")
        @android.webkit.JavascriptInterface fun openGameModeSettings(): String = openSystemScreen("android.settings.GAME_SETTINGS", "Abrindo as opções de modo de jogo, se o fabricante disponibilizar.")
        @android.webkit.JavascriptInterface fun openRefreshRateSettings(): String = openSystemScreen(Settings.ACTION_DISPLAY_SETTINGS, "Abrindo as configurações de tela para selecionar uma taxa de atualização suportada.")
        @android.webkit.JavascriptInterface fun setPrivateDns(host: String): String {
            if (Build.VERSION.SDK_INT < 28) return "Este Android não oferece DNS privado automático (requer Android 9 ou superior)."
            if (!hasPermission()) return "ERRO: inicie e autorize o Shizuku para alterar DNS pelo JURITI."
            val clean = host.trim().lowercase(java.util.Locale.ROOT)
            if (clean.isNotEmpty() && !clean.matches(Regex("[a-z0-9.-]{1,253}") ) ) return "ERRO: hostname DNS inválido."
            val command = if (clean.isEmpty()) "settings put global private_dns_mode opportunistic; settings delete global private_dns_specifier" else "settings put global private_dns_specifier '$clean' && settings put global private_dns_mode hostname"
            val result = runShell(command + "; echo MODE=$(settings get global private_dns_mode); echo HOST=$(settings get global private_dns_specifier)")
            if (result.startsWith("ERRO")) return result
            return if (clean.isEmpty() && result.contains("MODE=opportunistic")) "DNS privado automático restaurado." else if (clean.isNotEmpty() && result.contains("HOST=$clean")) "DNS privado configurado para $clean. A conexão pode levar alguns segundos para atualizar." else "O Android não confirmou a configuração DNS: $result"
        }

        @android.webkit.JavascriptInterface fun supportedRefreshRates(): String {
            return try {
                val dm = getSystemService(android.hardware.display.DisplayManager::class.java)
                val rates = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.supportedModes?.map { it.refreshRate }
                    ?.filter { it >= 30f }?.distinctBy { (it * 10).toInt() }?.sorted() ?: emptyList()
                JSONArray(rates).toString()
            } catch (_: Throwable) { "[]" }
        }

        @android.webkit.JavascriptInterface fun setRefreshRate(rate: Double): String {
            if (rate !in 30.0..240.0) return "ERRO: taxa fora do intervalo permitido."
            val supported = try { JSONArray(supportedRefreshRates()).let { a -> (0 until a.length()).map { a.getDouble(it) } } } catch (_: Throwable) { emptyList<Double>() }
            val actual = supported.minByOrNull { kotlin.math.abs(it-rate) } ?: return "O Android não informou modos de tela compatíveis neste aparelho."
            if (kotlin.math.abs(actual-rate) > 0.6) return "Taxa não suportada. Modos detectados: ${supported.joinToString(", ")} Hz."
            val result = runShell("settings put system peak_refresh_rate ${actual} && settings put system min_refresh_rate ${actual} && echo PEAK=$(settings get system peak_refresh_rate) && echo MIN=$(settings get system min_refresh_rate)")
            return if (!result.startsWith("ERRO") && result.contains("PEAK=${actual}")) "Solicitada taxa de ${actual} Hz. O fabricante ainda pode limitar a taxa conforme bateria, temperatura ou aplicativo." else "Não foi possível aplicar ${actual} Hz: $result"
        }

        @android.webkit.JavascriptInterface fun setAppStandby(packageName: String, bucket: String): String {
            if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return "ERRO: pacote inválido."
            if (packageName == this@MainActivity.packageName) return "ERRO: não altere a categoria do próprio JURITI."
            try { packageManager.getApplicationInfo(packageName, 0) } catch (_: Throwable) { return "ERRO: aplicativo não instalado." }
            val allowed = setOf("active", "working_set", "frequent", "rare")
            if (bucket !in allowed) return "ERRO: categoria inválida."
            val result = runShell("am set-standby-bucket '$packageName' '$bucket' 2>&1; am get-standby-bucket '$packageName' 2>&1")
            return if (result.startsWith("ERRO")) result else "Resposta do Android para $packageName: $result. Categorias menos ativas podem atrasar sincronizações e notificações."
        }

        @android.webkit.JavascriptInterface fun hardwareCapabilities(): String {
            val cpu = java.io.File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")
            val gpuPaths = listOf("/sys/class/devfreq", "/sys/class/kgsl/kgsl-3d0")
            val gpuExists = gpuPaths.any { java.io.File(it).exists() }
            val rates = supportedRefreshRates()
            val out = JSONObject().put("android", Build.VERSION.SDK_INT).put("cpuGovernorReadable", cpu.canRead())
                .put("cpuGovernors", if (cpu.canRead()) try { cpu.readText().trim() } catch (_: Throwable) { "" } else "")
                .put("gpuInterfaceDetected", gpuExists).put("refreshRates", JSONArray(rates))
                .put("privateDns", Build.VERSION.SDK_INT >= 28).put("shizuku", hasPermission())
            return out.toString()
        }
        @android.webkit.JavascriptInterface fun openBatteryManagement(): String = openSystemScreen(Settings.ACTION_BATTERY_SAVER_SETTINGS, "Abrindo gerenciamento de bateria do Android.")
        @android.webkit.JavascriptInterface fun openInputSettings(): String = openSystemScreen(Settings.ACTION_INPUT_METHOD_SETTINGS, "Abrindo configurações de entrada do Android.")
        @android.webkit.JavascriptInterface fun openSoundSettings(): String = openSystemScreen(Settings.ACTION_SOUND_SETTINGS, "Abrindo configurações de áudio do Android.")
        @android.webkit.JavascriptInterface fun openBatteryOptimizationSettings(): String = openSystemScreen(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, "Abrindo a lista oficial de otimização de bateria do Android.")
        @android.webkit.JavascriptInterface fun openGameDriverSettings(): String = openSystemScreen("android.settings.GAME_DRIVER_SETTINGS", "Abrindo as opções de driver de jogo, se disponíveis neste Android.")
        @android.webkit.JavascriptInterface fun setGameMode(packageName: String, mode: String): String {
            if (Build.VERSION.SDK_INT < 31) return "Este controle de modo de jogo requer Android 12 ou superior."
            if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return "ERRO: pacote inválido."
            if (packageName == this@MainActivity.packageName) return "ERRO: selecione um jogo, não o JURITI."
            val app = try { packageManager.getApplicationInfo(packageName, 0) } catch (_: Throwable) { return "ERRO: jogo não instalado." }
            val selected = when (mode) { "performance" -> "performance"; "battery" -> "battery"; "standard" -> "standard"; else -> return "ERRO: perfil inválido." }
            val result = runShell("cmd game mode $selected '$packageName' 2>&1; echo GAME_MODE=$(cmd game list-modes '$packageName' 2>&1)")
            return if (result.startsWith("ERRO")) result else "Solicitação de modo '$selected' enviada para ${app.loadLabel(packageManager)}. Resposta: $result. Alguns fabricantes não implementam todos os modos."
        }
        @android.webkit.JavascriptInterface fun applyGameBoost(packageName: String): String {
            if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return "ERRO: pacote inválido."
            val app = try { packageManager.getApplicationInfo(packageName, 0) } catch (_: Throwable) { return "ERRO: jogo não instalado." }
            if (app.packageName == this@MainActivity.packageName) return "ERRO: selecione um jogo, não o JURITI."
            if (!hasPermission()) return "ERRO: inicie o Shizuku e conceda autorização ao JURITI GAMER TURBO."
            val mode = setGameMode(packageName, "performance")
            val bucket = setAppStandby(packageName, "active")
            return "Impulso solicitado para ${app.loadLabel(packageManager)}.\nGame Mode: $mode\nPrioridade em espera: $bucket\nO Android/fabricante pode não implementar o perfil de desempenho. Limites térmicos e de segurança permanecem ativos."
        }

        @android.webkit.JavascriptInterface fun compileGame(packageName: String): String {
            // Accept only a package name returned by PackageManager; never pass arbitrary shell text.
            if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return "ERRO: pacote inválido."
            if (packageName == this@MainActivity.packageName) return "ERRO: selecione um jogo, não o JURITI."
            val appInfo = try { packageManager.getApplicationInfo(packageName, 0) } catch (_: Throwable) { return "ERRO: aplicativo não encontrado ou não instalado." }
            if (appInfo.packageName != packageName) return "ERRO: pacote não confirmado pelo Android."
            val result = runShell("cmd package compile -m speed-profile -f '$packageName' 2>&1")
            return if (result.startsWith("ERRO")) result else if (result.contains("Success", true) || result.contains("compiled", true) || result.equals("OK", true)) {
                "O Android concluiu a solicitação de compilação ART para ${appInfo.loadLabel(packageManager)}. Isso otimiza o código instalado e pode melhorar abertura/consistência, mas não garante aumento de FPS."
            } else {
                "O Android respondeu para ${appInfo.loadLabel(packageManager)}: $result. A compatibilidade depende da versão do sistema e do fabricante."
            }
        }

        @Suppress("DEPRECATION")
        @android.webkit.JavascriptInterface fun listInstalledGames(): String {
            return try {
                val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
                val rows = if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.ResolveInfoFlags.of(0)) else packageManager.queryIntentActivities(intent, 0)
                val arr = JSONArray()
                rows.distinctBy { it.activityInfo.packageName }.filter { it.activityInfo.packageName != packageName }
                    .sortedBy { it.loadLabel(packageManager).toString().lowercase(java.util.Locale.ROOT) }
                    .forEach { ri ->
                        val ai = ri.activityInfo.applicationInfo
                        val label = ri.loadLabel(packageManager).toString()
                        val isGame = Build.VERSION.SDK_INT >= 26 && ai.category == android.content.pm.ApplicationInfo.CATEGORY_GAME
                        arr.put(JSONObject().put("name", label).put("packageName", ai.packageName).put("isGame", isGame))
                    }
                arr.toString()
            } catch (e: Throwable) { "[]" }
        }

        @android.webkit.JavascriptInterface fun forceStopApp(packageName: String): String {
            if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return "ERRO: pacote inválido."
            if (packageName == this@MainActivity.packageName) return "ERRO: o JURITI não pode encerrar a si mesmo."
            val appInfo = try { packageManager.getApplicationInfo(packageName, 0) } catch (_: Throwable) { return "ERRO: aplicativo não encontrado ou não instalado." }
            if (appInfo.packageName != packageName) return "ERRO: pacote não confirmado pelo Android."
            val label = appInfo.loadLabel(packageManager).toString()
            val result = runShell("am force-stop --user current '$packageName' 2>&1; echo JURITI_FORCE_STOP_DONE")
            return if (result.startsWith("ERRO")) result else if (result.contains("JURITI_FORCE_STOP_DONE")) {
                "Solicitação de encerramento enviada para $label. O Android pode reiniciar serviços essenciais ou apps em segundo plano."
            } else "Resposta do Android ao encerrar $label: $result"
        }

        @android.webkit.JavascriptInterface fun launchGame(packageName: String): String {
            if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return "Pacote inválido."
            return try {
                val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return "Não encontrei uma tela de abertura para este aplicativo."
                // A limpeza ocorre antes de abrir o jogo somente quando o usuário deixa a opção ligada.
                val autoClean = getSharedPreferences("juriti_settings", MODE_PRIVATE).getBoolean("auto_clean_on_launch", true)
                val cleanResult = if (autoClean) trimAllAppCaches() else "Limpeza automática desativada."
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                if (autoClean && cleanResult.startsWith("ERRO")) "Jogo aberto; não foi possível solicitar a limpeza: $cleanResult"
                else if (autoClean) "Cache do aparelho: solicitação de limpeza enviada ao Android antes de abrir o jogo. O sistema remove apenas caches que puder liberar; dados e arquivos pessoais são preservados."
                else "Abrindo aplicativo."
            } catch (e: Throwable) { "Falha ao abrir: ${e.message}" }
        }

        private fun trimAllAppCaches(): String {
            if (!hasPermission()) return "ERRO: inicie o Shizuku e conceda autorização ao JURITI."
            // Solicita ao Package Manager o máximo de cache recuperável; o Android decide o que pode remover.
            return runShell("pm trim-caches 999000000000")
        }

        @android.webkit.JavascriptInterface fun resetAppSettings(): String {
            return try {
                // Restaura apenas preferências do JURITI; não apaga jogos, arquivos pessoais ou add-ons instalados.
                val settingsOk = getSharedPreferences("juriti_settings", MODE_PRIVATE).edit()
                    .clear().putBoolean("auto_clean_on_launch", true).commit()
                val addonPrefs = getSharedPreferences("juriti_addons", MODE_PRIVATE)
                val addonReset = addonPrefs.edit()
                addonPrefs.all.keys.filter { it.startsWith("enabled_") }.forEach { addonReset.putBoolean(it, false) }
                addonReset.commit()
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                val animationResult = if (hasPermission()) setAnimationProfile("normal")
                    else "Animações do Android não alteradas (Shizuku não autorizado)."
                if (!settingsOk) "ERRO: não foi possível salvar as configurações padrão."
                else "Configurações do JURITI restauradas. Limpeza automática ativada; painel flutuante encerrado. $animationResult"
            } catch (e: Throwable) {
                "ERRO: falha ao restaurar configurações: ${e.message ?: "erro do Android"}"
            }
        }

        @android.webkit.JavascriptInterface fun isAutoCleanOnLaunch(): Boolean =
            getSharedPreferences("juriti_settings", MODE_PRIVATE).getBoolean("auto_clean_on_launch", true)

        @android.webkit.JavascriptInterface fun setAutoCleanOnLaunch(enabled: Boolean): String {
            val prefs = getSharedPreferences("juriti_settings", MODE_PRIVATE)
            val saved = prefs.edit().putBoolean("auto_clean_on_launch", enabled).commit()
            if (!saved) return "ERRO: não foi possível salvar a configuração de limpeza automática."
            val confirmed = prefs.getBoolean("auto_clean_on_launch", !enabled)
            return if (confirmed == enabled) {
                if (enabled) "Limpeza automática ATIVADA. O JURITI GAMER TURBO solicitará a limpeza de cache antes de abrir jogos pela lista do aplicativo. Requer Shizuku autorizado para executar a limpeza."
                else "Limpeza automática DESATIVADA."
            } else "ERRO: o Android não confirmou a configuração."
        }

        @android.webkit.JavascriptInterface fun accelerate(): String = ""

        @android.webkit.JavascriptInterface fun cleanCaches(): String {
            val result = trimAllAppCaches()
            return if (result.startsWith("ERRO")) result else "Solicitação de limpeza de caches enviada ao Android para todos os aplicativos. O sistema remove os caches que puder liberar; dados, contas e arquivos pessoais não são apagados. Resultado: $result"
        }

        @android.webkit.JavascriptInterface fun killBackgroundApps(): String {
            if (!hasPermission()) return "ERRO: inicie o Shizuku e conceda autorização ao JURITI."
            // ActivityManager's kill-all operation targets cached/background processes; Android retains protected/foreground services.
            val result = runShell("am kill-all 2>&1; echo JURITI_KILL_ALL_DONE")
            return if (result.startsWith("ERRO")) result else if (result.contains("JURITI_KILL_ALL_DONE")) {
                "Comando de encerramento de processos em cache enviado ao Android. O sistema preserva processos protegidos/ativos quando necessário; a RAM pode voltar a ser usada automaticamente. Resposta: ${result.substringBefore("JURITI_KILL_ALL_DONE").trim().ifBlank { "concluído" }}"
            } else "O Android não confirmou o encerramento de processos em cache: $result"
        }

        @android.webkit.JavascriptInterface fun batterySaverState(): Boolean {
            return try { (getSystemService(POWER_SERVICE) as android.os.PowerManager).isPowerSaveMode } catch (_: Throwable) { false }
        }

        @android.webkit.JavascriptInterface fun toggleBatterySaver(enable: Boolean): String {
            val before = batterySaverState()
            if (before == enable) return if (enable) "Economia de bateria já está ativada." else "Economia de bateria já está desativada."
            if (!hasPermission()) return "ERRO: abra o Shizuku, inicie o serviço e conceda autorização ao JURITI GAMER TURBO."
            val mode = if (enable) 1 else 0
            val first = runShell("cmd power set-mode $mode 2>&1")
            var after = batterySaverState()
            if (after != enable) {
                // Compatibilidade com versões/fabricantes nos quais o subcomando power não está exposto.
                runShell("settings put global low_power $mode 2>&1")
                after = batterySaverState()
            }
            return if (after == enable) {
                if (enable) "Economia de bateria ATIVADA pelo JURITI GAMER TURBO." else "Economia de bateria DESATIVADA pelo JURITI GAMER TURBO."
            } else "ERRO: o Android não confirmou a alteração da economia de bateria. Resposta do sistema: $first. Verifique se o Shizuku está iniciado e autorizado; alguns fabricantes bloqueiam esse comando."
        }

        @android.webkit.JavascriptInterface fun dndState(): Boolean {
            return try {
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
            } catch (_: Throwable) { false }
        }

        @android.webkit.JavascriptInterface fun toggleDnd(enable: Boolean): String {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) {
                runOnUiThread { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (_: Throwable) {} }
                return "Conceda ao JURITI acesso a Não Perturbe nas configurações e tente novamente."
            }
            return try {
                nm.setInterruptionFilter(if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
                val confirmed = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
                if (confirmed == enable) {
                    if (enable) "Não Perturbe ativado (modo prioridade)." else "Não Perturbe desativado."
                } else "O Android não confirmou a alteração de Não Perturbe. Verifique a permissão do JURITI."
            } catch (e: Throwable) { "Não foi possível alterar Não Perturbe: ${e.message}" }
        }

        @android.webkit.JavascriptInterface fun applyMode(mode: String): String {
            return when (mode) {
                "battery" -> toggleBatterySaver(!batterySaverState())
                "balanced" -> setAnimationProfile("normal")
                "gamer" -> setAnimationProfile("off")
                else -> "Modo desconhecido."
            }
        }
        @android.webkit.JavascriptInterface fun openShizukuApp(): String {
            runOnUiThread {
                try {
                    val launch = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    if (launch != null) startActivity(launch) else startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            return "Abrindo Shizuku ou as configurações do Android."
        }

        @android.webkit.JavascriptInterface fun shizukuStatus(): String = when {
            !shizukuReady() -> "Shizuku não está iniciado. Abra o app Shizuku e inicie o serviço."
            !hasPermission() -> "Shizuku está iniciado, mas falta conceder permissão ao Juriti."
            else -> "Conectado e autorizado. UID do serviço: ${try { Shizuku.getUid() } catch (_: Throwable) { -1 }}"
        }

        @android.webkit.JavascriptInterface fun requestShizukuPermission(): String {
            return try {
                if (!shizukuReady()) "Abra o Shizuku e inicie o serviço primeiro."
                else if (hasPermission()) "O Juriti já tem permissão do Shizuku."
                else { runOnUiThread { Shizuku.requestPermission(requestCode) }; "Pedido de permissão enviado; aceite a janela do Shizuku." }
            } catch (e: Throwable) { "Não foi possível pedir permissão: ${e.message}" }
        }

        @android.webkit.JavascriptInterface fun setAnimationProfile(profile: String): String {
            val value = when (profile) { "fast" -> "0.5"; "normal" -> "1.0"; "off" -> "0.0"; else -> return "Perfil inválido." }
            val command = "settings put global window_animation_scale $value && settings put global transition_animation_scale $value && settings put global animator_duration_scale $value && echo 'Animações configuradas' && settings get global window_animation_scale && settings get global transition_animation_scale && settings get global animator_duration_scale"
            return runShell(command)
        }

        @android.webkit.JavascriptInterface fun readAnimationScales(): String = runShell("echo 'Escala de janela:'; settings get global window_animation_scale; echo 'Escala de transição:'; settings get global transition_animation_scale; echo 'Duração do animador:'; settings get global animator_duration_scale")

        private fun openSystemScreen(action: String, message: String): String {
            runOnUiThread {
                try { startActivity(Intent(action)) }
                catch (_: Throwable) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Throwable) {} }
            }
            return message
        }

        @android.webkit.JavascriptInterface fun openBatterySettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de bateria do Android."
        }

        @android.webkit.JavascriptInterface fun openDisplaySettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de tela do Android."
        }

        @android.webkit.JavascriptInterface fun openDndSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de Não Perturbe. O Android pode exigir autorização própria."
        }

        @android.webkit.JavascriptInterface fun openApplicationSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo a lista de aplicativos nas configurações do Android. Escolha o app para ver armazenamento e limpar somente o cache."
        }

        @android.webkit.JavascriptInterface fun openBatteryUsageSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo uso da bateria. As opções de restrição dependem do Android e do fabricante."
        }

        @android.webkit.JavascriptInterface fun openStorageSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de armazenamento. Nenhum arquivo foi apagado."
        }

        /**
         * Diagnostic command palette used by the Optimization tab.
         * Only fixed, read-only commands are accepted; no arbitrary shell input is exposed to WebView.
         */
        @android.webkit.JavascriptInterface fun runTurboDiagnostic(tool: String): String {
            if (!hasPermission()) return "ERRO: inicie o Shizuku e conceda autorização ao JURITI."
            val command = when (tool) {
                "device" -> "echo 'Fabricante:'; getprop ro.product.manufacturer; echo 'Modelo:'; getprop ro.product.model; echo 'Android:'; getprop ro.build.version.release; echo 'SDK:'; getprop ro.build.version.sdk; echo 'Build:'; getprop ro.build.display.id"
                "battery" -> "dumpsys battery"
                "thermal" -> "dumpsys thermalservice"
                "memory" -> "echo 'Memória disponível (/proc/meminfo):'; cat /proc/meminfo | head -n 12; echo; echo 'Resumo de processos:'; dumpsys meminfo | head -n 35"
                "display" -> "dumpsys display | head -n 45"
                "network" -> "echo 'Modo DNS privado:'; settings get global private_dns_mode; echo 'Host DNS privado:'; settings get global private_dns_specifier; echo 'DNS do sistema:'; getprop net.dns1; getprop net.dns2"
                "properties" -> "echo 'ro.product.manufacturer:'; getprop ro.product.manufacturer; echo 'ro.product.model:'; getprop ro.product.model; echo 'ro.build.version.release:'; getprop ro.build.version.release; echo 'ro.build.version.sdk:'; getprop ro.build.version.sdk; echo 'ro.build.version.security_patch:'; getprop ro.build.version.security_patch; echo 'ro.hardware:'; getprop ro.hardware; echo 'ro.soc.model:'; getprop ro.soc.model"
                else -> return "ERRO: consulta desconhecida. Selecione uma opção predefinida."
            }
            val result = runShell(command)
            if (result.startsWith("ERRO")) return result
            return result.take(6500).ifBlank { "O Android não retornou dados para esta consulta." }
        }

        @android.webkit.JavascriptInterface fun thermalStatus(): String {
            return try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    val power = getSystemService(POWER_SERVICE) as android.os.PowerManager
                    val status = power.currentThermalStatus
                    val label = when (status) {
                        android.os.PowerManager.THERMAL_STATUS_NONE -> "Normal"
                        android.os.PowerManager.THERMAL_STATUS_LIGHT -> "Leve"
                        android.os.PowerManager.THERMAL_STATUS_MODERATE -> "Moderado"
                        android.os.PowerManager.THERMAL_STATUS_SEVERE -> "Alto"
                        android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "Crítico"
                        android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergência"
                        android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "Desligamento térmico iminente"
                        else -> "Indisponível"
                    }
                    "Estado térmico do sistema: $label (nível $status). O Android não forneceu temperatura em °C."
                } else "Este Android não disponibiliza a API de estado térmico usada pelo Juriti."
            } catch (e: Throwable) { "Não foi possível consultar o estado térmico: ${e.message ?: "indisponível"}" }
        }
    }

    private fun addonListJson(): JSONArray {
        val result = JSONArray()
        val root = java.io.File(filesDir, "juriti-addons")
        root.listFiles()?.filter { it.isDirectory }?.forEach { dir ->
            try {
                val file = java.io.File(dir, "manifest.json")
                if (!file.isFile || file.length() > 64 * 1024) return@forEach
                val manifest = JSONObject(file.readText())
                result.put(JSONObject().put("id", dir.name).put("name", manifest.optString("name", dir.name))
                    .put("version", manifest.optString("version", "1.0")).put("description", manifest.optString("description", ""))
                    .put("actions", manifest.optJSONArray("actions") ?: JSONArray())
                    .put("enabled", getSharedPreferences("juriti_addons", MODE_PRIVATE).getBoolean("enabled_${dir.name}", true)))
            } catch (_: Throwable) { }
        }
        return result
    }

    private fun installJuritiAddon(uri: android.net.Uri) {
        try {
            val temp = java.io.File(cacheDir, "addon-import-${System.currentTimeMillis()}.zip")
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw IllegalArgumentException("Não foi possível ler o ZIP.")
                temp.outputStream().use { output ->
                    val buffer = ByteArray(8192); var total = 0L
                    while (true) { val n = input.read(buffer); if (n < 0) break; total += n; if (total > 20L * 1024 * 1024) throw IllegalArgumentException("ZIP excede o limite de 20 MB."); output.write(buffer, 0, n) }
                }
            }
            var manifest: JSONObject? = null
            var entries = 0
            java.util.zip.ZipInputStream(temp.inputStream().buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entries++
                    if (entries > 100) throw IllegalArgumentException("ZIP contém arquivos demais.")
                    val name = entry.name.replace('\\', '/')
                    if (name.startsWith("/") || name.split('/').any { it == ".." } || name.contains(":") ) throw IllegalArgumentException("O ZIP contém um caminho inseguro.")
                    if (!entry.isDirectory && name == "manifest.json") {
                        val bytes = zip.readBytes()
                        if (bytes.size > 64 * 1024) throw IllegalArgumentException("manifest.json excede 64 KB.")
                        manifest = JSONObject(String(bytes, Charsets.UTF_8))
                    }
                    zip.closeEntry()
                }
            }
            temp.delete()
            val m = manifest ?: throw IllegalArgumentException("ZIP inválido: coloque manifest.json na raiz do pacote.")
            val id = m.optString("id", "").trim()
            val name = m.optString("name", "").trim()
            val version = m.optString("version", "1.0").trim()
            if (!id.matches(Regex("[a-zA-Z0-9._-]{1,64}"))) throw IllegalArgumentException("ID inválido no manifest.json.")
            if (name.isBlank() || name.length > 80) throw IllegalArgumentException("O nome do add-on está ausente ou é muito longo.")
            if (version.length > 32) throw IllegalArgumentException("Versão inválida.")
            val actions = m.optJSONArray("actions") ?: JSONArray()
            if (actions.length() > 20) throw IllegalArgumentException("Máximo de 20 ações por add-on.")
            val allowed = setOf("open_game_tools", "open_dns_settings", "open_animation_settings", "open_performance", "open_shizuku", "open_battery_settings", "open_sound_settings", "open_input_settings", "open_display_settings", "open_game_driver_settings", "open_battery_optimization", "open_private_dns_settings")
            for (i in 0 until actions.length()) {
                val action = actions.optString(i)
                if (action !in allowed) throw IllegalArgumentException("Ação não suportada no pacote: $action")
            }
            val root = java.io.File(filesDir, "juriti-addons")
            val dir = java.io.File(root, id)
            if (!root.exists() && !root.mkdirs()) throw IllegalStateException("Não foi possível criar a pasta de add-ons.")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Não foi possível preparar a pasta do add-on.")
            java.io.File(dir, "manifest.json").writeText(m.toString())
            getSharedPreferences("juriti_addons", MODE_PRIVATE).edit().putBoolean("enabled_$id", true).apply()
            webView.post { webView.evaluateJavascript("renderJuritiAddons()", null) }
            jsMessage("Add-on '$name' instalado. Somente ações permitidas pelo JURITI são aceitas.")
        } catch (e: Throwable) {
            jsMessage("Falha ao instalar ZIP: ${e.message ?: "arquivo inválido"}")
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == addonZipRequestCode && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) installJuritiAddon(uri) else jsMessage("Nenhum arquivo ZIP selecionado.")
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.post { webView.evaluateJavascript("if(window.refreshNativeOverlaySwitch){refreshNativeOverlaySwitch();}", null) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 0, 15)
        window.navigationBarColor = Color.rgb(7, 0, 15)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        webView.setBackgroundColor(Color.rgb(7, 0, 15))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = true
        webView.addJavascriptInterface(AppBridge(), "JuritiNative")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        setContentView(webView)
        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permissionResultListener) } catch (_: Throwable) {}
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
