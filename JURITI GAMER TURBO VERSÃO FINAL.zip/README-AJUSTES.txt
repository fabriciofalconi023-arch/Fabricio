Ajuste visual adicional:
- A caixa escura de retorno abaixo do texto das Ações Rápidas foi aumentada ligeiramente.
- A caixa de retorno do Perfil de desempenho real recebeu a mesma altura (76 px), mantendo os dois painéis proporcionais.
- Nenhuma funcionalidade ou lógica Android foi alterada.

- Balão de retorno das Ações Rápidas com largura reduzida e centralizada para proporção melhor.
- Aviso de conexão Shizuku aproximado do botão de monitor de desempenho.
